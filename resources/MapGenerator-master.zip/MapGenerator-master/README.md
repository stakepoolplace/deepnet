MapGenerator
============

3d TriangleMesh from image tool
